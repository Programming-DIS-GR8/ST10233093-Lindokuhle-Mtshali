/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task2;
import javax.swing.JOptionPane;
import java.util.Random;

/**
 *
 * @author ST10233093
 */
public class taskClass {
    taskClass gg = new taskClass();
    
    int length = 50;
public static boolean examineTaskDescription(String bb){
        boolean check = false;
    for(int h=0; h<bb.length(); h++){
        if(bb.charAt(h)<=50){
            check = true;
        }
    }
    if(check== true && check){
        System.out.println("Task successfully record");
    }else{
            System.out.println("Enter task description of 50 or less characters");
            }
    return true;
    }

public static void CreateTaskID(String ii){
    Random get = new Random();
int i = get.nextInt(99)+10;
        
    }
public static void printTaskDetails(String aa, String bb, int cc, String dd,String ee, String ff){
    Task2 aaa = new Task2();
    taskClass gg = new taskClass();
    String result;
    result = JOptionPane.showInputDialog("Hello first employee, what is your name? ");
    
    JOptionPane.showMessageDialog(null, result + ' ' + "Task Status: " + ff + "\n" + "Developer description: " + ee + "\n" + "Task number: " + dd + "\n" + "task name: " + dd + "\n" + "Task Description: " + bb + "\n" + "Task duration: " + ee );
}
public static void returnTotalHours(String ee){
    
for(int h=0; h<ee.length(); h++){
    System.out.println("task Duration" + h++);
}
}
    
}
